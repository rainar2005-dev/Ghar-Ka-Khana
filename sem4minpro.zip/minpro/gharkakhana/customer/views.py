from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from .forms import SignupForm, LoginForm
from django.conf import settings
from django.contrib import messages
from .models import Item, Customer, Review
from vendor.models import Vendor
import random
from django.core.mail import send_mail
import qrcode
from io import BytesIO
import base64
from django.shortcuts import render
from django.urls import reverse
from django.utils import timezone
from django.db.models import Avg, Count

def customer_dashboard(request):
 return render(request,"navbar.html",{})

def generate_otp():
    return str(random.randint(100000, 999999))

def send_otp_email(email, otp):
    subject = "Your OTP for Ghar Ka Khana Signup"
    message = f"Your OTP for signup is: {otp}. This OTP will expire in 10 minutes."
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [email]
    
    try:
        send_mail(subject, message, from_email, recipient_list, fail_silently=False)
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

def signup_view(request):
    if request.method == 'POST':
        if 'verify_otp' in request.POST:
            # Handle OTP verification
            stored_otp = request.session.get('signup_otp')
            submitted_otp = request.POST.get('otp')
            
            if stored_otp and submitted_otp == stored_otp:
                # OTP is correct, proceed with user creation
                form_data = request.session.get('signup_form_data')
                if form_data:
                    try:
                        # Create user with form data
                        user = Customer.objects.create(
                            name=form_data.get('name'),
                            email=form_data.get('email'),
                            phone=form_data.get('phone'),
                            address=form_data.get('address'),
                            username=form_data.get('email')  # Use email as username
                        )
                        user.set_password(form_data.get('password'))
                        user.save()
                        
                        # Clear session data
                        del request.session['signup_otp']
                        del request.session['signup_form_data']
                        
                        messages.success(request, "Account created successfully! Please login.")
                        return redirect('customer:login')
                    except Exception as e:
                        messages.error(request, f"Error creating account: {str(e)}")
                        return render(request, 'customer.html')
            else:
                messages.error(request, "Invalid OTP. Please try again.")
                return render(request, 'verify_otp.html', {'email': request.session.get('signup_form_data', {}).get('email')})
        
        else:
            # Handle initial form submission
            name = request.POST.get('name')
            email = request.POST.get('email')
            phone = request.POST.get('phone')
            password = request.POST.get('password')
            address = request.POST.get('address')
            
            if name and email and phone and password and address:
                # Validate email format
                if '@' not in email or '.' not in email:
                    messages.error(request, "Please enter a valid email address")
                    return render(request, 'customer.html')
                
                # Validate phone number format
                if not phone.isdigit() or len(phone) < 10:
                    messages.error(request, "Please enter a valid phone number")
                    return render(request, 'customer.html')
                
                # Validate password length
                if len(password) < 6:
                    messages.error(request, "Password must be at least 6 characters long")
                    return render(request, 'customer.html')
                
                # Check if user already exists
                if Customer.objects.filter(email=email).exists():
                    messages.error(request, "Email already registered")
                    return render(request, 'customer.html')
                
                # Generate and send OTP
                otp = generate_otp()
                
                if send_otp_email(email, otp):
                    # Store form data and OTP in session
                    request.session['signup_otp'] = otp
                    request.session['signup_form_data'] = request.POST.dict()
                    return render(request, 'verify_otp.html', {'email': email})
                else:
                    messages.error(request, "Failed to send OTP. Please try again.")
            else:
                messages.error(request, "Please fill in all fields")
    
    return render(request, 'customer.html')

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        if not email or not password:
            messages.error(request, "Please provide both email and password")
            return render(request, 'login.html')
        
        try:
            user = Customer.objects.get(email=email)
            if user.check_password(password):
                login(request, user)
                messages.success(request, "Login successful!")
                return redirect('customer:menu')
            else:
                messages.error(request, "Invalid email or password")
        except Customer.DoesNotExist:
            messages.error(request, "Invalid email or password")
    
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

def details_view(request, item_id):
    # Hardcoded menu items data
    menu_items = {
        1: {
            'name': 'Free Meal',
            'price': 1,
            'description': 'Suprise',
            'image': 'free.jpg'
        },
        2: {
            'name': 'Basic Veg Meal',
            'price': 150,
            'description': 'A wholesome vegetarian meal including dal, rice, vegetables, and chapati. Perfect for a healthy and satisfying lunch or dinner.',
            'image': 'basicveg.webp'
        },
        3: {
            'name': 'Basic Non-Veg Meal',
            'price': 200,
            'description': 'A delicious non-vegetarian meal featuring chicken curry, rice, dal, and chapati. A perfect blend of protein and taste.',
            'image': 'basicnon.jpeg'
        },
        4: {
            'name': 'Standard Veg Meal',
            'price': 180,
            'description': 'An enhanced vegetarian meal with additional variety of vegetables, special dal, and fresh chapati.',
            'image': 'standveg.jpg'
        },
        5: {
            'name': 'Standard Non-Veg Meal',
            'price': 220,
            'description': 'A premium non-vegetarian meal with chicken curry, fish curry, rice, dal, and fresh chapati.',
            'image': 'standnonveg.jpg'
        },
        6: {
            'name': '2 Weeks Vegetarian Plan',
            'price': 499,
            'description': 'A Standard vegetarian meal plan for 2 weeks, including a variety of dishes to keep your meals exciting and nutritious.',
            'image': '2wveg.jpg'
        },
        7: {
            'name': '1 Month Vegetarian Plan',
            'price': 799,
            'description': 'A Standard vegetarian meal plan for 2 weeks, featuring a variety of side dishes.',
            'image': 'oneveg.jpg'
        },
        8: {
            'name': 'One month Vegetarian + Non Vegetarian Plan',
            'price': 999,
            'description': 'A Standard vegetarian and non vegtarian meal plan for 1 month, featuring a variety of chicken and fish dishes also veg side dishes.',
            'image': 'onevegnon.jpg'
        },
    }
    
    # Get the menu item based on item_id
    menu_item = menu_items.get(item_id)
    if not menu_item:
        messages.error(request, "Menu item not found")
        return redirect('customer:menu')
    
    return render(request, 'details.html', {'menu_item': menu_item})

def generate_qr(request, order_id):
    payment_link = f"https://paymentgateway.com/pay/{order_id}"
    qr = qrcode.make(payment_link)
    buffer = BytesIO()
    qr.save(buffer, format="PNG")
    return HttpResponse(buffer.getvalue(), content_type="image/png")

def menu_view(request):
    return render(request, 'menu.html')

def home(request):
    return render(request, 'home.html')

def submit_order(request):
    print("Submit order view called")  # Debug print
    if request.method == 'POST':
        print("POST request received")  # Debug print
        print("POST data:", request.POST)  # Debug print
        try:
            # Get form data
            name = request.POST.get('name')
            phone = request.POST.get('phone')
            email = request.POST.get('email')
            address = request.POST.get('address')
            address_type = request.POST.get('address_type')
            delivery_time = request.POST.get('delivery_time')
            quantity = request.POST.get('quantity')
            menu_item_id = request.POST.get('menu_item_id')
            menu_item_name = request.POST.get('menu_item_name')
            menu_item_price = request.POST.get('menu_item_price')

            print(f"Form data received: name={name}, phone={phone}, email={email}")  # Debug print
            print(f"Menu item data: id={menu_item_id}, name={menu_item_name}, price={menu_item_price}")  # Debug print

            # Generate a random order ID
            order_id = random.randint(1000, 9999)
            print(f"Generated order ID: {order_id}")  # Debug print
            
            # Calculate total amount
            total_amount = float(menu_item_price) * int(quantity)
            print(f"Calculated total amount: {total_amount}")  # Debug print
            
            # Store order details in session
            order_details = {
                'order_id': order_id,
                'name': name,
                'phone': phone,
                'email': email,
                'address': address,
                'address_type': address_type,
                'delivery_time': delivery_time,
                'quantity': quantity,
                'menu_item_name': menu_item_name,
                'menu_item_price': menu_item_price,
                'total_amount': total_amount
            }
            request.session['order_details'] = order_details
            print(f"Stored order details in session: {order_details}")  # Debug print
            
            print(f"Redirecting to payment page with order_id: {order_id}")  # Debug print
            # Redirect to payment page
            return redirect('customer:payment', order_id=order_id)
            
        except Exception as e:
            print(f"Error in submit_order: {str(e)}")  # Debug print
            messages.error(request, f"Error submitting order: {str(e)}")
            return redirect('customer:menu')
    
    print("Not a POST request, redirecting to menu")  # Debug print
    return redirect('customer:menu')

def assign_vendor_to_customer(customer_id):
    """Assign a vendor to a customer based on availability"""
    try:
        # Get all vendors
        vendors = Vendor.objects.all()
        
        # Find vendor with least customers
        min_customers = float('inf')
        selected_vendor = None
        
        for vendor in vendors:
            current_customers = len(vendor.get_customers_list())
            if current_customers < min_customers:
                min_customers = current_customers
                selected_vendor = vendor
        
        if selected_vendor:
            # Get current customers list
            current_customers = selected_vendor.get_customers_list()
            
            # Add new customer if not already in list
            if customer_id not in current_customers:
                current_customers.append(customer_id)
                selected_vendor.set_customers_list(current_customers)
            
            return selected_vendor
                
        return None
    except Exception as e:
        print(f"Error assigning vendor: {str(e)}")
        return None

def payment_view(request, order_id):
    if request.method == 'POST':
        # Get order details from session
        order_details = request.session.get('order_details')
        if not order_details or order_details['order_id'] != order_id:
            messages.error(request, "Invalid order")
            return redirect('customer:menu')
        
        # Get assigned vendor from session
        assigned_vendor = request.session.get('order_details', {}).get('assigned_vendor')
        
        if assigned_vendor:
            try:
                vendor = Vendor.objects.get(Vendor_Id=assigned_vendor['id'])
                print(f"Found vendor: {vendor.Vendor_Name}")  # Debug log
                
                # Get current orders
                vendor_orders = vendor.get_orders_list()
                print(f"Current vendor orders: {vendor_orders}")  # Debug log
                
                # Create new order
                new_order = {
                    'order_id': order_details['order_id'],
                    'customer_id': request.user.id,
                    'customer_name': request.user.get_full_name() or request.user.username,
                    'menu_item': order_details['menu_item_name'],
                    'quantity': order_details['quantity'],
                    'total_amount': order_details['total_amount'],
                    'order_date': str(timezone.now().date()),
                    'status': 'pending'
                }
                
                # Append new order to list
                vendor_orders.append(new_order)
                print(f"Adding new order: {new_order}")  # Debug log
                print(f"Updated vendor orders: {vendor_orders}")  # Debug log
                
                # Save the updated orders list
                vendor.set_orders_list(vendor_orders)
                
                # Verify the orders were saved
                vendor.refresh_from_db()
                saved_orders = vendor.get_orders_list()
                print(f"Verified saved orders: {saved_orders}")  # Debug log
                
                if not saved_orders:
                    print("WARNING: Orders list is empty after save!")  # Debug log
                    print(f"Raw Orders_List field: {vendor.Orders_List}")  # Debug log
            except Vendor.DoesNotExist:
                print(f"Vendor not found: {assigned_vendor['id']}")  # Debug log
            except Exception as e:
                print(f"Error saving order: {str(e)}")  # Debug log
        else:
            print("No vendor was assigned!")  # Debug log
        
        # Prepare success message with order and vendor details
        success_message = f"""
        Payment Successful!
        Order ID: {order_details['order_id']}
        Amount: ₹{order_details['total_amount']}
        Delivery Time: {order_details['delivery_time']}
        """
        
        if assigned_vendor:
            success_message += f"""
            Your order has been assigned to:
            Vendor: {assigned_vendor['name']}
            Contact: {assigned_vendor['phone']}
            """
        
        messages.success(request, success_message)
        
        # Clear order details from session after successful payment
        if 'order_details' in request.session:
            del request.session['order_details']
        if 'payment_completed' in request.session:
            del request.session['payment_completed']
        
        return render(request, 'payment_success.html', {
            'order_details': order_details,
            'assigned_vendor': assigned_vendor
        })
    
    # Get order details from session
    order_details = request.session.get('order_details')
    
    if not order_details or order_details['order_id'] != order_id:
        messages.error(request, "Invalid order")
        return redirect('customer:menu')
    
    # Clear any previous payment completed flag if it exists
    if 'payment_completed' in request.session:
        del request.session['payment_completed']
    
    success_url = reverse('customer:payment_success', kwargs={'order_id': order_id})
    payment_url = f"http://127.0.0.1:8000{success_url}"
    
    # Assign vendor to customer if not already assigned
    if request.user.is_authenticated:
        assigned_vendor = assign_vendor_to_customer(request.user.id)
        if assigned_vendor:
            order_details['assigned_vendor'] = {
                'id': assigned_vendor.Vendor_Id,
                'name': assigned_vendor.Vendor_Name,
                'phone': assigned_vendor.Vendor_Phone
            }
            request.session['order_details'] = order_details
    
    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(payment_url)
    qr.make(fit=True)
    qr_image = qr.make_image(fill_color="black", back_color="white")
    
    # Convert QR code to base64 for embedding in template
    buffered = BytesIO()
    qr_image.save(buffered, format="PNG")
    qr_image_base64 = base64.b64encode(buffered.getvalue()).decode()
    
    context = {
        'order_details': order_details,
        'qr_code': qr_image_base64,
        'payment_url': payment_url
    }
    
    return render(request, 'payment.html', context)

def payment_success(request, order_id):
    if request.method == 'POST':
        # Get order details from session
        order_details = request.session.get('order_details')
        
        if not order_details or order_details['order_id'] != order_id:
            messages.error(request, "Invalid order")
            return redirect('customer:menu')
        
        # Mark payment as completed in session
        request.session['payment_completed'] = True
        
        # Get the assigned vendor details
        assigned_vendor = order_details.get('assigned_vendor')
        
        # Prepare success message with order and vendor details
        success_message = f"""
        Payment Successful!
        Order ID: {order_details['order_id']}
        Amount: ₹{order_details['total_amount']}
        Delivery Time: {order_details['delivery_time']}
        """
        
        if assigned_vendor:
            success_message += f"""
            Your order has been assigned to:
            Vendor: {assigned_vendor['name']}
            Contact: {assigned_vendor['phone']}
            """
        
        messages.success(request, success_message)
        
        # Clear order details from session after successful payment
        del request.session['order_details']
        del request.session['payment_completed']  # Clear payment completed flag
        
        return render(request, 'payment_success.html', {
            'order_details': order_details,
            'assigned_vendor': assigned_vendor
        })
    
    # If it's a GET request, redirect to menu
    return redirect('customer:menu')

def payment_page(request, order_id):
    return render(request, 'payment.html', {'order_id': order_id})

@login_required
def service_view(request):
    print("Service view called")  # Debug log
    
    if request.method == 'POST':
        print("POST request received")  # Debug log
        print("POST data:", request.POST)  # Debug log
        print("FILES:", request.FILES)  # Debug log
        
        rating = request.POST.get('rating')
        content = request.POST.get('review')
        photos = request.FILES.getlist('photos')
        
        print(f"Received review submission - Rating: {rating}, Content: {content}")  # Debug log
        
        if not rating or not content:
            print("Missing rating or content")  # Debug log
            messages.error(request, "Please provide both rating and review content.")
            return redirect('customer:service')
        
        try:
            rating = int(rating)
            if rating < 1 or rating > 5:
                print(f"Invalid rating value: {rating}")  # Debug log
                messages.error(request, "Rating must be between 1 and 5.")
                return redirect('customer:service')
            
            print(f"Creating review for user: {request.user.username}")  # Debug log
            
            # Create the review
            review = Review.objects.create(
                user=request.user,
                rating=rating,
                content=content,
                is_verified_order=True
            )
            print(f"Created review with ID: {review.id}")  # Debug log
            
            # Handle photo uploads
            for photo in photos:
                if photo:
                    review.photos = photo
                    review.save()
                    print(f"Added photo to review {review.id}")  # Debug log
                    break
            
            messages.success(request, "Thank you for your review!")
            return redirect('customer:service')
        except ValueError as e:
            print(f"ValueError while creating review: {str(e)}")  # Debug log
            messages.error(request, "Invalid rating value.")
            return redirect('customer:service')
        except Exception as e:
            print(f"Error creating review: {str(e)}")  # Debug log
            messages.error(request, f"Error submitting review: {str(e)}")
            return redirect('customer:service')
    
    # Get all reviews with related user data
    reviews = Review.objects.select_related('user').all().order_by('-created_at')
    print(f"Found {reviews.count()} reviews")  # Debug log
    
    # Print each review's details for debugging
    for review in reviews:
        print(f"Review ID: {review.id}, User: {review.user.username}, Rating: {review.rating}, Content: {review.content}")
    
    # Calculate average rating and total reviews
    stats = reviews.aggregate(
        avg_rating=Avg('rating'),
        total_reviews=Count('id')
    )
    
    # Calculate rating distribution
    rating_distribution = {
        '5': reviews.filter(rating=5).count(),
        '4': reviews.filter(rating=4).count(),
        '3': reviews.filter(rating=3).count(),
        '2': reviews.filter(rating=2).count(),
        '1': reviews.filter(rating=1).count()
    }
    
    print(f"Average rating: {stats['avg_rating']}, Total reviews: {stats['total_reviews']}")  # Debug log
    
    context = {
        'reviews': reviews,
        'avg_rating': round(stats['avg_rating'] or 0, 1),
        'total_reviews': stats['total_reviews'],
        'rating_distribution': rating_distribution,
        'service_content': {
            'title': 'Our Services',
            'description': 'Ghar Ka Khana provides delicious homemade food delivered right to your doorstep.',
            'features': [
                'Fresh, homemade food',
                'Wide variety of dishes',
                'Timely delivery',
                'Quality ingredients',
                'Hygienic packaging'
            ]
        }
    }
    
    return render(request, 'services.html', context)

@login_required
def mark_review_helpful(request, review_id):
    if request.method == 'POST':
        try:
            review = Review.objects.get(id=review_id)
            review.helpful_count += 1
            review.is_helpful = True
            review.save()
            return JsonResponse({
                'success': True,
                'helpful_count': review.helpful_count
            })
        except Review.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Review not found'
            }, status=404)
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': str(e)
            }, status=500)
    return JsonResponse({
        'success': False,
        'message': 'Invalid request method'
    }, status=405)

@login_required
def like_review(request, review_id):
    if request.method == 'POST':
        try:
            review = Review.objects.get(id=review_id)
            review.likes_count += 1
            review.is_liked = True
            review.save()
            return JsonResponse({
                'success': True,
                'likes_count': review.likes_count
            })
        except Review.DoesNotExist:
            return JsonResponse({
                'success': False,
                'message': 'Review not found'
            }, status=404)
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': str(e)
            }, status=500)
    return JsonResponse({
        'success': False,
        'message': 'Invalid request method'
    }, status=405)