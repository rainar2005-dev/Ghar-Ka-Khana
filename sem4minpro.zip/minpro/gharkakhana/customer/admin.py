from django.contrib import admin
from .models import Customer, Review  # Import your models

admin.site.register(Customer)  # Register your model
admin.site.register(Review)

