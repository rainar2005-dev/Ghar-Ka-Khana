from django.urls import path
from . import views
from .views import menu_view
from .views import payment_success  

app_name='customer'
urlpatterns = [
path('dashboard/', views.customer_dashboard, name='customer_dashboard'),
path('customer-signup/', views.signup_view, name='signup'),
path('login/', views.login_view, name='login'),
path('menu/', views.menu_view, name='menu'),
path('logout/', views.logout_view, name='logout'),
path('', views.home, name='home'),
path('details/<int:item_id>/', views.details_view, name='details'),
path('submit-order/', views.submit_order, name='submit_order'),
path('payment/<int:order_id>/', views.payment_view, name='payment'),
path('payment-success/<int:order_id>/', payment_success, name='payment_success'),
path('service/', views.service_view, name='service'),
path('review/helpful/<int:review_id>/', views.mark_review_helpful, name='mark_review_helpful'),
path('review/like/<int:review_id>/', views.like_review, name='like_review'),
]
